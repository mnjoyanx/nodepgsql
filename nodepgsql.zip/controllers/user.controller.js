
class UserController {
    async getAll(req, res) { 
        const { name, username } = req.body
        return res.json('ok')
    }
    async getOne(req, res) {

    }
    async createUser(req, res) { 


    }
    async updateUser(req, res) {

    }
    async deleteUser(req, res) {}
} 


module.exports = UserController